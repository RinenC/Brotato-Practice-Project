﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

/*
    플레이어 스테이터스 목록
    1. 최대HP
    2. HP재생
    3. % 생명력 흡수
    4. % 데미지
    5. 근거리 데미지
    6. 원거리 데미지
    7. 원소 데미지
    8. % 공격 속도
    9. % 치명타율
    10. 엔지니어링
    11. 범위
    12. 방어구
    13. 회피
    14. 속도
    15. 행운
    16. 수확
    */

public class CSVWriter : MonoBehaviour
{
    string filename = "";

    [System.Serializable]

    public class Player
    {
        public int idx;
        public string name;
        public float maxhp;
        public float hpreg;
        public float leech;
        public float dmgper;
        public float meeledmg;
        public float rangedmg;
        public float eledmg;
        public float atkspd;
        public float critchan;
        public float engineer;
        public float atkrange;
        public float armor;
        public float avoid;
        public float movespd;
        public float luck;
        public float income;
    }
    
    [System.Serializable]
    public class PlayerList
    {
        public Player[] player;
    }

    public PlayerList MyplayerList = new PlayerList();

    void Awake()
    {
        filename = Application.dataPath + "/test.csv";
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            WriteCSV();
        }
    }

    public void WriteCSV()
    {
        if(MyplayerList.player.Length > 0)
        {
            TextWriter tw = new StreamWriter(filename, false);
            tw.WriteLine("idx, name, maxhp, hpreg, leech, dmgper, meeledmg, rangedmg, eledmg, atkspd, critchan, engineer, atkrange, armor, avoid, movespd, luck, income");
            tw.Close();

            tw = new StreamWriter(filename, true);

            for(int i = 0; i <MyplayerList.player.Length; i++)
            {
                tw.WriteLine(MyplayerList.player[i].idx + "," + MyplayerList.player[i].name + "," +
                             MyplayerList.player[i].maxhp + "," + MyplayerList.player[i].hpreg + "," +
                             MyplayerList.player[i].leech + "," + MyplayerList.player[i].dmgper + "," +
                             MyplayerList.player[i].meeledmg + "," + MyplayerList.player[i].rangedmg + "," +
                             MyplayerList.player[i].eledmg + "," + MyplayerList.player[i].atkspd + "," +
                             MyplayerList.player[i].critchan + "," + MyplayerList.player[i].engineer + "," +
                             MyplayerList.player[i].atkrange + "," + MyplayerList.player[i].armor + "," +
                             MyplayerList.player[i].avoid + "," + MyplayerList.player[i].movespd + "," +
                             MyplayerList.player[i].luck + "," + MyplayerList.player[i].income);
            }
            tw.Close();
        }
    }
}
