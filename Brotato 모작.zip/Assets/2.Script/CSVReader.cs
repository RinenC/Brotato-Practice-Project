﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class CSVReader : MonoBehaviour
{
    public TextAsset textAssetData;

    [System.Serializable]
    public class Player
    {
        public int idx;
        public string name;
        public float maxhp;
        public float hpreg;
        public float leech;
        public float dmgper;
        public float meeledmg;
        public float rangedmg;
        public float eledmg;
        public float atkspd;
        public float critchan;
        public float engineer;
        public float atkrange;
        public float armor;
        public float avoid;
        public float movespd;
        public float luck;
        public float income;
    }
    [System.Serializable]
    public class PlayerList
    {
        public Player[] player;
    }

    public PlayerList myPlayerList = new PlayerList();
    void Start()
    {
        ReadCSV();
    }

    void ReadCSV()
    {
        string[] data = textAssetData.text.Split(new string[] { ",", "\n" }, StringSplitOptions.None);

        int tableSize = data.Length / 18 - 1;
        myPlayerList.player = new Player[tableSize];

        for (int i = 0; i < tableSize; i++)
        {
            myPlayerList.player[i] = new Player();
            myPlayerList.player[i].name = data[18 * (i + 1)];
            myPlayerList.player[i].maxhp = float.Parse(data[18 * (i + 1) + 1]);
        }
    }
}
