﻿using UnityEngine;

[CreateAssetMenu(fileName = "StatusDB", menuName = "ScriptableObject/StatusScriptableObject", order = 1)]
public class PlayerStatus : ScriptableObject
{
    /*
    플레이어 스테이터스 목록
    1. 최대HP
    2. HP재생
    3. % 생명력 흡수
    4. % 데미지
    5. 근거리 데미지
    6. 원거리 데미지
    7. 원소 데미지
    8. % 공격 속도
    9. % 치명타율
    10. 엔지니어링
    11. 범위
    12. 방어구
    13. 회피
    14. 속도
    15. 행운
    16. 수확
    */
    public float maxhpf;
    public float hpregf;
    public float leechf;
    public float dmgperf;
    public float meeledmgf;
    public float rangedmgf;
    public float elementdmgf;
    public float attackspeedf;
    public float critchancef;
    public float engineeringf;
    public float attackrangef;
    public float armorf;
    public float avoidf;
    public float movespeedf;
    public float luckf;
    public float incomef;
}
