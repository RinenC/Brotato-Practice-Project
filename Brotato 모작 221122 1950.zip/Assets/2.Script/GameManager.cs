﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public Player player;
    public GUIManager guiManager;
    public RandomSpawnManager rsm;

    public static GameManager GetInstance()
    {
        return instance;
    }

    public static GameManager instance = null;

    void Awake()
    {
        instance = this;
    }

    void Update()
    {
        
    }

    public void GameoverCheck()
    {
        if (player.curhp > 0)
            guiManager.playerdeath = false;
        else if (player.curhp <= 0)
            guiManager.playerdeath = true;

        if (guiManager.playerdeath == true)
            rsm.Delete();
    }

    public void EventExit()
    {
        Application.Quit();
    }

    public void EventReset()
    {
        player.curhp = player.status.maxhp;
        guiManager.scenechangetime = 3f;
        guiManager.curwavetime = guiManager.wavetime;
        rsm.Delete();
    }
}
