﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Reward : MonoBehaviour
{
    public Image rewardImage;
    public Text rewardText;
    public Button rewardButton;

    public enum RewNum
    {
        Rew1,
        Rew2,
        Rew3,
        Rew4,
    }

    public RewNum curRewNum;

    public enum RewStat
    {
        maxhp,
        hpreg,
        leech,
        dmgper,
        meeledmg,
        rangedmg,
        eledmg,
        atkspd,
        critchance,
        engineer,
        atkrange,
        armor,
        avoid,
        movespd,
        luck,
        income,
        max
    }

    public RewStat curStat;

    void Start()
    {
        curStat = (RewStat)(0);
        RewardStatus();
    }

    void Update()
    {

    }

    public void RewardStatus()
    {
        switch (curRewNum)
        {
            case RewNum.Rew1:
                SetResStat((RewStat)(RewardManager.Instance.randomList[0]));
                break;
            case RewNum.Rew2:
                SetResStat((RewStat)(RewardManager.Instance.randomList[1]));
                break;
            case RewNum.Rew3:
                SetResStat((RewStat)(RewardManager.Instance.randomList[2]));
                break;
            case RewNum.Rew4:
                SetResStat((RewStat)(RewardManager.Instance.randomList[3]));
                break;
        }
    }
    public void SetResStat(RewStat stat)
    {
        switch (stat)
        {
            case RewStat.maxhp:
                break;
            case RewStat.hpreg:
                break;
            case RewStat.leech:
                break;
            case RewStat.dmgper:
                break;
            case RewStat.meeledmg:
                break;
            case RewStat.rangedmg:
                break;
            case RewStat.eledmg:
                break;
            case RewStat.atkspd:
                break;
            case RewStat.critchance:
                break;
            case RewStat.engineer:
                break;
            case RewStat.atkrange:
                break;
            case RewStat.armor:
                break;
            case RewStat.avoid:
                break;
            case RewStat.movespd:
                break;
            case RewStat.luck:
                break;
            case RewStat.income:
                break;
        }
        curStat = stat;
    }

    public void ImageChange()
    {
        switch (curRewNum)
        {
            case RewNum.Rew1:
                rewardImage.GetComponent<Image>().sprite = RewardManager.Instance.imageSource[RewardManager.Instance.randomList[0]];
                break;
            case RewNum.Rew2:
                rewardImage.GetComponent<Image>().sprite = RewardManager.Instance.imageSource[RewardManager.Instance.randomList[1]];
                break;
            case RewNum.Rew3:
                rewardImage.GetComponent<Image>().sprite = RewardManager.Instance.imageSource[RewardManager.Instance.randomList[2]];
                break;
            case RewNum.Rew4:
                rewardImage.GetComponent<Image>().sprite = RewardManager.Instance.imageSource[RewardManager.Instance.randomList[3]];
                break;
        }
    }
}