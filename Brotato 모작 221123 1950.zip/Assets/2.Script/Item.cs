﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    void Start()
    {

    }

    void Update()
    {

    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (ItemManager.Instance.curstate == ItemManager.ItemTypeE.EXP)
        {
            if (collision.gameObject.CompareTag("Player"))
            {
                GUIManager.Instance.curExp += 10;
                Destroy(this.gameObject);
            }
        }
        else if (ItemManager.Instance.curstate == ItemManager.ItemTypeE.HP)
        {
            if (collision.gameObject.CompareTag("Player"))
            {
                GUIManager.Instance.curhp += 2;
                Destroy(this.gameObject);
            }
        }
    }
}
