﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Weapon : MonoBehaviour
{
    public Player player;
    public GameObject objBullet;

    GameObject TargetGO;
    Bullet CopyBullet;

    float shotDelay;
    float shotAfterTime;
    void Start()
    {
        shotDelay = 1f / player.status.atkspd;
    }

    void Update()
    {
        if (DistanceCheck() == true && shotAfterTime >= shotDelay)
            Shot();
        else
            shotAfterTime += Time.deltaTime;
    }


    public bool DistanceCheck()
    {
        if (RandomSpawnManager.Instance.monsterList.Count == 0)
        {
            return false;
        }

        var sortedList = RandomSpawnManager.Instance.monsterList.OrderBy(x => Vector3.Distance(x.transform.position, player.transform.position)).ToList();

        TargetGO = sortedList[0];
        Vector3 vPos = player.transform.position;

        float fDist = Vector3.Distance(TargetGO.transform.position, vPos);

        if (fDist < player.status.atkrange)
            return true;
        else
            return false;
    }

    public void Shot()
    {
        CopyBullet = Instantiate(objBullet, transform.position, Quaternion.identity).GetComponent<Bullet>();
        CopyBullet.player = player;
        Vector3 vDist = TargetGO.transform.position - transform.position;
        Vector3 vDir = vDist.normalized;
        CopyBullet.vDist = vDir;
        shotAfterTime = 0f;
    }
}