﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoSingleton<GameManager>
{
    public Player player;

    void Update()
    {
        
    }

    public void GameoverCheck()
    {
        if (GUIManager.Instance.curhp > 0)
            GUIManager.Instance.playerdeath = false;
        else if (GUIManager.Instance.curhp <= 0)
            GUIManager.Instance.playerdeath = true;

        if (GUIManager.Instance.playerdeath == true)
            RandomSpawnManager.Instance.Delete();
    }

    public void EventExit()
    {
        Application.Quit();
    }

    public void EventReset()
    {
        GUIManager.Instance.curhp = player.status.maxhp;
        GUIManager.Instance.scenechangetime = 3f;
        GUIManager.Instance.curwavetime = GUIManager.Instance.wavetime;
        RandomSpawnManager.Instance.Delete();
    }
}
