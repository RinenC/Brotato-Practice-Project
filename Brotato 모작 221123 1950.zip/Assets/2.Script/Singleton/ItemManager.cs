﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemManager : MonoSingleton<ItemManager>
{
    public enum ItemTypeE { EXP, HP, MAX }
    public ItemTypeE curstate;
    GameObject _expitem;

    public List<Sprite> expitemSprite;

    void Awake()
    {

    }

    void Update()
    {

    }

    public void SetItemType(ItemTypeE itemtype)
    {
        switch (itemtype)
        {
            case ItemTypeE.EXP:
                break;
            case ItemTypeE.HP:
                break;
            default:
                break;
        }
        curstate = itemtype;
    }

    public void ExpItemSprite(GameObject expitem)
    {
        var random = Random.Range(0, 3);
        expitem = _expitem;
        _expitem.GetComponent<SpriteRenderer>().sprite = expitemSprite[random];
    }
}
