﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Text;
using Newtonsoft.Json;

[System.Serializable]
public class Status
{
    public int idx;
    public string name;
    public int maxhp;
    public int hpreg;
    public int leech;
    public int dmgper;
    public int meeledmg;
    public int rangedmg;
    public int eledmg;
    public int atkspd;
    public int critchance;
    public int engineer;
    public int atkrange;
    public int armor;
    public int avoid;
    public int movespd;
    public int luck;
    public int income;
}

public class DBLoader : MonoSingleton<DBLoader>
{
    public Player player;

    static List<Status> characterStatusList = new List<Status>();

    void Awake()
    {
        TextAsset textAsset = Resources.Load<TextAsset>("CharacterStatus");
        characterStatusList = JsonConvert.DeserializeObject<List<Status>>(textAsset.text);

        player.SetStatus(GetCharacterStatusByIdx(0));

        //jsonutility는 list를 못쳐읽어옴

        //var list = new List<Status>();

        //var status = new Status();
        //status.name = "asdf";

        //list.Add(status);

        //Debug.Log(JsonUtility.ToJson(list, true));
    }

    //Generic 공부
    static T DeepCopy<T>(T obj)
    {
        var json = JsonConvert.SerializeObject(obj);
        var tmp = JsonConvert.DeserializeObject<T>(json);

        return tmp;
    }
    
    //람다식 + Linq 공부할것
    public static Status GetCharacterStatusByIdx(int idx)
    {
        return DeepCopy(characterStatusList.Find(x => x.idx == idx));
    }

    
    //Singleton 제작. (GameManager)
    //자료구조 공부할것
}
