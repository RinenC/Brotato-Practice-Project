﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public enum sceneE
{
    TITLE,
    PLAY,
    SHOP,
    GAMEOVER,
    CLEAR,
}

[DisallowMultipleComponent]
public class GUIManager : MonoSingleton<GUIManager>
{
    public Player player;// { get; protected set; }

    public GameObject waveendT;
    public Weapon weapon;

    public List<GameObject> listGUIScenes;

    public RewardPopup rewardPopup;

    public sceneE curScene;

    private void Awake()
    {
        Initialize();
    }

    void Update()
    {
        GameManager.Instance.GameoverCheck();
        HPBarControll();
        ExpBarControll();
        GoldControll();
        WaveControll();
        GameOver();
        UITest();
    }

    public void Initialize()
    {
        SetGUIState(curScene);
        rewardPopup.gameObject.SetActive(false);
        //scenechangetime = GameManager.GetInstance().scenechangetime;
        //playerdeath = GameManager.GetInstance().playerdeath;
    }

    public void ShowGUIState(sceneE scene)
    {
        for (int i = (int)sceneE.TITLE; i < (EnumHelper.GetEnumMemberCnt(typeof(sceneE))); i++)
        {
            if (i == (int)scene)
                listGUIScenes[(int)i].SetActive(true);
            else
                listGUIScenes[(int)i].SetActive(false);
        }
    }

    public void SetGUIState(sceneE scene)
    {
        switch (scene)
        {
            case sceneE.TITLE:
                Time.timeScale = 0;
                break;
            case sceneE.PLAY:
                curwavetime = wavetime + 1;
                curhp = player.status.maxhp;
                Time.timeScale = 1;
                RandomSpawnManager.Instance.StartCoroutine("Spawn", wavetime);
                break;
            case sceneE.SHOP:
                Time.timeScale = 0;
                waveEnd = false;
                wave++;
                wavetime += 5;
                scenechangetime = 3f;
                curwavetime = wavetime + 1;
                RandomSpawnManager.Instance.count += 20;
                break;
            case sceneE.GAMEOVER:
                Time.timeScale = 0;
                GameManager.Instance.EventReset();
                break;
            case sceneE.CLEAR:
                Time.timeScale = 0;
                waveEnd = false;
                GameManager.Instance.EventReset();
                break;
        }
        ShowGUIState(scene);
        curScene = scene;
    }

    public void UpdateGUIState()
    {
        switch (curScene)
        {
            case sceneE.TITLE:
                break;
            case sceneE.PLAY:
                break;
            case sceneE.SHOP:
                break;
            case sceneE.GAMEOVER:
                break;
        }
    }

    public void EventSenceChange(int idx)
    {
        SetGUIState((sceneE)idx);
    }

    [SerializeField]
    public float maxExp = 100;
    public float curExp = 0;
    public float curhp;
    public float gold = 0;
    public int lv = 1;
    public int wave = 1;
    public float wavetime = 20f;
    public float curwavetime;
    public float scenechangetime = 3f;
    public int rewardcount = 0;

    bool testStart;
    public bool waveEnd;
    public bool playerdeath;
    public bool isReward;

    public Slider hpBar;
    public Slider expBar;

    public Text hpText;
    public Text level;
    public Text goldT;
    public Text waveT;
    public Text timer;

    public void HPBarControll()
    {
        hpBar.value = curhp / (float)player.status.maxhp;
        hpText.text = curhp + " / " + player.status.maxhp;
    }

    public void ExpBarControll()
    {
        expBar.value = curExp / maxExp;

        if (curExp >= maxExp)
        {
            float addexp = curExp - maxExp;
            curExp = 0;
            rewardcount++;
            lv++;
            maxExp = maxExp + 50;
            curExp = addexp;
        }

        level.text = "LV . " + lv;
    }

    public void GoldControll()
    {
        goldT.text = "" + gold;
    }

    public void WaveControll()
    {
        waveT.text = "웨이브 " + wave;
        if (curwavetime > 6)
        {
            timer.color = Color.white;
            timer.text = "" + (int)curwavetime;
        }
        else if (curwavetime <= 6)
        {
            timer.color = Color.red;
            timer.text = "" + (int)curwavetime;
        }
        if (waveEnd == false)
        {
            waveendT.gameObject.SetActive(false);
            if (playerdeath == false)
                curwavetime -= Time.deltaTime;
            else if (playerdeath == true)
                RandomSpawnManager.Instance.Delete();
        }
        if (curwavetime <= 0)
        {
            waveEnd = true;
            if (wave < 20)
            {
                if (waveEnd == true)
                {
                    waveendT.SetActive(true);
                    RandomSpawnManager.Instance.Delete();
                    if (scenechangetime > 0)
                    {
                        scenechangetime -= Time.deltaTime;
                    }
                    if (scenechangetime <= 0)
                    {
                        if (rewardcount > 0)
                        {
                            Time.timeScale = 0;
                            if (!isReward)
                            {
                                rewardPopup.gameObject.SetActive(true);
                                rewardPopup.Init();
                                isReward = true;
                            }
                        }
                        else if (rewardcount <= 0)
                        {
                            waveEnd = false;
                            SetGUIState(sceneE.SHOP);
                        }
                    }
                }
            }
            else if (wave >= 20)
            {
                if (waveEnd == true)
                {
                    waveendT.SetActive(true);
                    RandomSpawnManager.Instance.Delete();
                    if (scenechangetime > 0)
                    {
                        scenechangetime -= Time.deltaTime;
                    }
                    if (scenechangetime <= 0)
                    {
                        SetGUIState(sceneE.CLEAR);
                    }
                }
            }
        }
    }

    public void RewardButtonClick()
    {
        isReward = false;
    }

    public void rewardselect()
    {
        if (rewardcount > 0)
            rewardcount--;
        else if (rewardcount <= 0)
            SetGUIState(sceneE.SHOP);
    }

    public void GameOver()
    {
        if (playerdeath == false) { }
        else if (playerdeath == true)
        {
            if (scenechangetime > 0)
            {
                scenechangetime -= Time.deltaTime;
            }
            else if (scenechangetime <= 0)
            {
                SetGUIState(sceneE.GAMEOVER);
            }
        }
    }

    public void UITest()
    {
        if (Input.GetKeyDown(KeyCode.Backspace))
        {
            if (testStart == false)
            {
                testStart = true;
                Debug.Log("UI Test Mode Started.");
            }
            else if (testStart == true)
            {
                testStart = false;
                Debug.Log("UI Test Mode Ended.");
            }
        }

        if (testStart == true)
        {
            if (Input.GetKeyDown(KeyCode.K))
            {
                if (curhp > 0)
                {
                    curhp = curhp - 1;
                    Debug.Log("HP UI TEST");
                }
                else if (curhp <= 0)
                {
                    Debug.Log("Low HP");
                }
            }

            if (Input.GetKeyDown(KeyCode.E))
            {
                curExp = curExp + 50;
                Debug.Log("EXP UI TEST");
            }

            if (Input.GetKeyDown(KeyCode.G))
            {
                gold = gold + 10;
                Debug.Log("Gold UI TEST");
            }
        }
    }
}
