﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Text;
using Newtonsoft.Json;

[System.Serializable]
public class Status
{
    public int idx;
    public string name;
    public float maxhp;
    public float hpreg;
    public float leech;
    public float dmgper;
    public float meeledmg;
    public float rangedmg;
    public float eledmg;
    public float atkspd;
    public float critchance;
    public float engineer;
    public float atkrange;
    public float armor;
    public float avoid;
    public float movespd;
    public float luck;
    public float income;
}

public class DBLoader : MonoSingleton<DBLoader>
{
    static List<Status> characterStatusList = new List<Status>();
    
    public Player player;

    [Header("스텟 스프라이트")]
    public Sprite maxHpSprite;
    public Sprite RegHpSprite;
    public Sprite LeechSprite;
    public Sprite DMGPERSprite;
    public Sprite MeeleDMGsprite;
    public Sprite RangeDMGSprite;
    public Sprite EleDMGSprite;
    public Sprite ATKSPDSprite;
    public Sprite CritChanSprite;
    public Sprite EngineerSprite;
    public Sprite ATKRangeSprite;
    public Sprite ArmorSprite;
    public Sprite AvoidSprite;
    public Sprite MoveSPDSprite;
    public Sprite LUCKSprite;
    public Sprite IncomeSprite;

    void Awake()
    {
        TextAsset textAsset = Resources.Load<TextAsset>("CharacterStatus");
        characterStatusList = JsonConvert.DeserializeObject<List<Status>>(textAsset.text);

        player.SetStatus(GetCharacterStatusByIdx(0));

        //jsonutility는 list를 못쳐읽어옴

        //var list = new List<Status>();

        //var status = new Status();
        //status.name = "asdf";

        //list.Add(status);

        //Debug.Log(JsonUtility.ToJson(list, true));
    }

    //Generic 공부
    static T DeepCopy<T>(T obj)
    {
        var json = JsonConvert.SerializeObject(obj);
        var tmp = JsonConvert.DeserializeObject<T>(json);

        return tmp;
    }
    
    //람다식 + Linq 공부할것
    public static Status GetCharacterStatusByIdx(int idx)
    {
        return DeepCopy(characterStatusList.Find(x => x.idx == idx));
    }


    //Singleton 제작. (GameManager)
    //자료구조 공부할것

    public Sprite GetStatSprite(RewStat statType)
    {
        switch (statType)
        {
            case RewStat.Maxhp:
                return maxHpSprite;
            case RewStat.HpReg:
                return RegHpSprite;
            case RewStat.Leech:
                return LeechSprite;
            case RewStat.Dmgper:
                return DMGPERSprite;
            case RewStat.Meeledmg:
                return MeeleDMGsprite;
            case RewStat.Rangedmg:
                return RangeDMGSprite;
            case RewStat.Eledmg:
                return EleDMGSprite;
            case RewStat.Atkspd:
                return ATKSPDSprite;
            case RewStat.Critchance:
                return CritChanSprite;
            case RewStat.Engineer:
                return EngineerSprite;
            case RewStat.Atkrange:
                return ATKRangeSprite;
            case RewStat.Armor:
                return ArmorSprite;
            case RewStat.Avoid:
                return AvoidSprite;
            case RewStat.Movespd:
                return MoveSPDSprite;
            case RewStat.Luck:
                return LUCKSprite;
            case RewStat.Income:
                return IncomeSprite;
            default:
                return null;
        }
    }
}
