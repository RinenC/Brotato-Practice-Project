﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Text;

public class DBLoader : MonoBehaviour
{
    [System.Serializable]
    public class Status
    {
        public int idx;
        public string name;
        public int maxhp;
        public int hpreg;
        public int leech; 
        public int dmgper;
        public int meeledmg;
        public int rangedmg;
        public int eledmg;
        public int atkspd;
        public int critchance;
        public int engineer;
        public int atkrange;
        public int armor;
        public int avoid;
        public int movespd;
        public int luck;
        public int income;
    }

    void Start()
    { 
        TextAsset textAsset = Resources.Load<TextAsset>("CharacterStatus");

        Debug.Log(textAsset.text);

        Status it = JsonUtility.FromJson<Status>(textAsset.text);

        Debug.Log(it.name);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
