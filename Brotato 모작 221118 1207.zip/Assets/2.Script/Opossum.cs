﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Opossum : MonoBehaviour
{
    public GameObject playerGO;
    public Player player;
    public float speed = 0.8f;

    public bool isTrigger = false;
    public float attackCooltime = 1f;
    public float attackAfterTime = 0f;

    public float attackPower = 1f;

    void Start()
    {
        attackAfterTime = 0f;
    }

    void Update()
    {
        MoveProcess();

        attackAfterTime -= Time.deltaTime;

        if (attackAfterTime <= 0 && isTrigger)
        {
            player.curhp -= attackPower;
            attackAfterTime = attackCooltime;
        }
    }

    public void MoveProcess()
    {
        Vector3 vTargetPos = playerGO.transform.position;
        Vector3 vMyPos = transform.position;

        Vector3 vDist = vTargetPos - vMyPos;//위치의 차이를 이용한 거리구하기
        Vector3 vDir = vDist.normalized;//두물체사이의 방향(평준화-거리를뺀 이동량) //< normalized = 길이가 1인 백터 ( 힘이 1이고 방향만 있음.) 상태로 만들어줌.
        float fDist = vDist.magnitude; //두물체사이의 거리(스칼라-순수이동량)

        if (fDist > speed * Time.deltaTime)//한프레임의 이동거리보다 클때만 이동한다.
        {
            transform.position += vDir * speed * Time.deltaTime;
        }
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            isTrigger = true;
        }
    }

    public void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            isTrigger = false;
        }
    }
}
