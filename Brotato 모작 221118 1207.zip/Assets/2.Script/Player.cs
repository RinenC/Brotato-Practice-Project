﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public class Player : MonoBehaviour
{
    //float maxhpf;
    //float hpregf;
    //float leechf;
    //float dmgperf;
    //float meeledmgf;
    //float rangedmgf;
    //float elementdmgf;
    //float attackspeedf;
    //float critchancef;
    //float engineeringf;
    //float attackrangef;
    //float armorf;
    //float avoidf;
    //float movespeedf;
    //float luckf;
    //float incomef;

    public Status status;// { get; protected set; }

    public float curhp;
    public bool playerdeath;

    public GUIManager gUIManager;

    void Awake()
    {
        curhp = status.maxhp;
        Debug.Log(curhp);
    }

    void Update()
    {
        MoveProcess();
    }

    public void SetStatus(Status _status)
    {
        status = _status;

        Debug.Log(status.name);
    }

    public void MoveProcess()
    {
        if (gUIManager.waveEnd == false && playerdeath == false)
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                transform.position += Vector3.up * Time.deltaTime;
            }
            if (Input.GetKey(KeyCode.DownArrow))
            {
                transform.position += Vector3.down * Time.deltaTime;
            }
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                transform.position += Vector3.left * Time.deltaTime;
            }
            if (Input.GetKey(KeyCode.RightArrow))
            {
                transform.position += Vector3.right * Time.deltaTime;
            }
        }
    }

    public void Deathcheck()
    {
        if (curhp > 0)
            playerdeath = false;
        else if (curhp <= 0)
            playerdeath = true;
    }
}
