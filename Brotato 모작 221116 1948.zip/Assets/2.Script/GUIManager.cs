﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public class GUIManager : MonoBehaviour
{
    public Player player;// { get; protected set; }

    [SerializeField]
    float maxExp = 100;
    float curExp = 0;
    int gold = 0;
    int lv = 1;
    int wave = 1;
    float time = 21f;

    bool testStart;
    bool waveEnd;

    public Slider hpBar;
    public Slider expBar;

    public Text hpText;
    public Text level;
    public Text goldT;
    public Text waveT;
    public Text timer;

    void Update()
    {
        HPBarControll();
        ExpBarControll();
        GoldControll();
        WaveControll();
        UITest();
    }

    public void HPBarControll()
    {
        hpBar.value = player.curhp / (float)player.status.maxhp;
        hpText.text = player.curhp + " / " + player.status.maxhp;
    }

    public void ExpBarControll()
    {
        expBar.value = curExp / maxExp;

        if (curExp >= maxExp)
        {
            curExp = 0;
            lv++;
            maxExp = maxExp + 50;
        }

        level.text = "LV . " + lv;
    }

    public void GoldControll()
    {
        goldT.text = "" + gold;
    }

    public void WaveControll()
    {
        waveT.text = "웨이브 " + wave;
        if (time > 11)
            timer.text = "" + (int)time;
        else if (time <= 11)
        {
            timer.color = Color.red;
            timer.text = "" + (int)time;
        }
        if (waveEnd == false)
            time -= Time.deltaTime;
        if (time <= 0)
        {
            waveEnd = true;
            if (waveEnd == true)
            {
                Debug.Log("Wave End");
            }
        }
    }

    public void UITest()
    {
        if (Input.GetKeyDown(KeyCode.Backspace))
        {
            if (testStart == false)
            {
                testStart = true;
                Debug.Log("UI Test Mode Started.");
            }
            else if (testStart == true)
            {
                testStart = false;
                Debug.Log("UI Test Mode Ended.");
            }
        }

        if (testStart == true)
        {
            if (Input.GetKeyDown(KeyCode.K))
            {
                if (player.curhp > 0)
                {
                    player.curhp = player.curhp - 1;
                    Debug.Log("HP UI TEST");
                }
                else if (player.curhp <= 0)
                {
                    Debug.Log("Low HP");
                }
            }

            if (Input.GetKeyDown(KeyCode.E))
            {
                curExp = curExp + 50;
                Debug.Log("EXP UI TEST");
            }

            if (Input.GetKeyDown(KeyCode.G))
            {
                gold = gold + 10;
                Debug.Log("Gold UI TEST");
            }
        }
    }
}
