﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Text;
using Newtonsoft.Json;

[System.Serializable]
public class Status
{
    public int idx;
    public string name;
    public float maxhp;
    public float hpreg;
    public float leech;
    public float dmgper;
    public float meeledmg;
    public float rangedmg;
    public float eledmg;
    public float atkspd;
    public float critchance;
    public float engineer;
    public float atkrange;
    public float armor;
    public float avoid;
    public float movespd;
    public float luck;
    public float income;
}

public class DBLoader : MonoSingleton<DBLoader>
{
    static List<Status> characterStatusList = new List<Status>();
    
    public Player player;

    [Header("스텟 스프라이트")]
    public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;
    //public Sprite maxHpSprite;

    void Awake()
    {
        TextAsset textAsset = Resources.Load<TextAsset>("CharacterStatus");
        characterStatusList = JsonConvert.DeserializeObject<List<Status>>(textAsset.text);

        player.SetStatus(GetCharacterStatusByIdx(0));

        //jsonutility는 list를 못쳐읽어옴

        //var list = new List<Status>();

        //var status = new Status();
        //status.name = "asdf";

        //list.Add(status);

        //Debug.Log(JsonUtility.ToJson(list, true));
    }

    //Generic 공부
    static T DeepCopy<T>(T obj)
    {
        var json = JsonConvert.SerializeObject(obj);
        var tmp = JsonConvert.DeserializeObject<T>(json);

        return tmp;
    }
    
    //람다식 + Linq 공부할것
    public static Status GetCharacterStatusByIdx(int idx)
    {
        return DeepCopy(characterStatusList.Find(x => x.idx == idx));
    }


    //Singleton 제작. (GameManager)
    //자료구조 공부할것

    public Sprite GetStatSprite(RewStat statType)
    {
        switch (statType)
        {
            case RewStat.Maxhp:
                return maxHpSprite;
            //case RewStat.HpReg:
            //    break;
            //case RewStat.Leech:
            //    break;
            //case RewStat.Dmgper:
            //    break;
            //case RewStat.Meeledmg:
            //    break;
            //case RewStat.Rangedmg:
            //    break;
            //case RewStat.Eledmg:
            //    break;
            //case RewStat.Atkspd:
            //    break;
            //case RewStat.Critchance:
            //    break;
            //case RewStat.Engineer:
            //    break;
            //case RewStat.Atkrange:
            //    break;
            //case RewStat.Armor:
            //    break;
            //case RewStat.Avoid:
            //    break;
            //case RewStat.Movespd:
            //    break;
            //case RewStat.Luck:
            //    break;
            //case RewStat.Income:
            //    break;
            //case RewStat.Max:
            //    break;
            default:
                return null;
        }
    }
}
