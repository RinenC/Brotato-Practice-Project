﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RewardSlotData
{
    public RewStat rewStat;
    public int value;
}

public class RewardSlot : MonoBehaviour
{
    [SerializeField] Image itemImg;
    [SerializeField] Text itemNameText;
    [SerializeField] Button positiveBtn;

    public RewardSlotData data { get; private set; }

    private void Awake()
    {
        positiveBtn.onClick.AddListener(GetReward);
    }

    public void InitSlot(RewardSlotData _data)
    {
        data = _data;

        if (data == null)
            return;

        //< string.format 공부할것
        switch (data.rewStat)
        {
            case RewStat.Maxhp:
                //itemImg.sprite = "모시깽이";
                itemNameText.text = $"최대 체력 +{data.value:N0}";
                break;
            case RewStat.HpReg:
                itemNameText.text = $"체력 재생 +{data.value:N0}";
                break;
            case RewStat.Leech:
                itemNameText.text = $"흡혈 +{data.value:N0}%";
                break;
            case RewStat.Dmgper:
                break;
            case RewStat.Meeledmg:
                break;
            case RewStat.Rangedmg:
                break;
            case RewStat.Eledmg:
                break;
            case RewStat.Atkspd:
                break;
            case RewStat.Critchance:
                break;
            case RewStat.Engineer:
                break;
            case RewStat.Atkrange:
                break;
            case RewStat.Armor:
                break;
            case RewStat.Avoid:
                break;
            case RewStat.Movespd:
                break;
            case RewStat.Luck:
                break;
            case RewStat.Income:
                break;
            case RewStat.Max:
                break;
        }

        itemImg.sprite = DBLoader.Instance.GetStatSprite(data.rewStat);
    }

    public void GetReward()
    {
        var player = GameManager.Instance.player;

        switch (data.rewStat)
        {
            default:
                player.status.maxhp += data.value;
                GUIManager.Instance.curhp += data.value;
                break;
                //case RewStat.Maxhp:
                //    player.status.maxhp += data.value;
                //    break;
                //case RewStat.Hpreg:
                //    break;
                //case RewStat.Leech:
                //    break;
                //case RewStat.Dmgper:
                //    break;
                //case RewStat.Meeledmg:
                //    break;
                //case RewStat.Rangedmg:
                //    break;
                //case RewStat.Eledmg:
                //    break;
                //case RewStat.Atkspd:
                //    break;
                //case RewStat.Critchance:
                //    break;
                //case RewStat.Engineer:
                //    break;
                //case RewStat.Atkrange:
                //    break;
                //case RewStat.Armor:
                //    break;
                //case RewStat.Avoid:
                //    break;
                //case RewStat.Movespd:
                //    break;
                //case RewStat.Luck:
                //    break;
                //case RewStat.Income:
                //    break;
                //case RewStat.Max:
                //    break;
        }

        GUIManager.Instance.rewardcount--;
        if (GUIManager.Instance.rewardcount <= 0)
        {
            GUIManager.Instance.rewardPopup.gameObject.SetActive(false);
            GUIManager.Instance.SetGUIState(sceneE.SHOP);
        }
        else
            GUIManager.Instance.rewardPopup.Init();
    }
}
