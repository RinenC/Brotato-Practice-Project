﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Reward : MonoBehaviour
{
    public enum ResStat 
    {
        maxhp,
        hpreg,
        leech,
        dmgper,
        meeledmg,
        rangedmg,
        eledmg,
        atkspd,
        critchance,
        engineer,
        atkrange,
        armor,
        avoid,
        movespd,
        luck,
        income,
    }

    public ResStat curStat;

    void Start()
    {
        curStat = ResStat.maxhp;
    }

    void Update()
    {
        
    }

    public void RewardStatus()
    {
        
    }
}
