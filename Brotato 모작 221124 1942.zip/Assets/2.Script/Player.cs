﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public class Player : MonoBehaviour
{
    //float maxhpf;
    //float hpregf;
    //float leechf;
    //float dmgperf;
    //float meeledmgf;
    //float rangedmgf;
    //float elementdmgf;
    //float attackspeedf;
    //float critchancef;
    //float engineeringf;
    //float attackrangef;
    //float armorf;
    //float avoidf;
    //float movespeedf;
    //float luckf;
    //float incomef;

    public Status status;// { get; protected set; }
    public Sprite live;
    public Sprite death;

    public bool playerdeath;
    float range;

    void Awake()
    {
        GUIManager.Instance.curhp = status.maxhp;
        range = status.atkrange / 2;
    }

    void Update()
    {
        MoveProcess();
        Deathcheck();
    }

    public void SetStatus(Status _status)
    {
        status = _status;

        Debug.Log(status.name);
    }

    public void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(this.transform.position, range);
    }

    public void MoveProcess()
    {
        if (GUIManager.Instance.waveEnd == false && playerdeath == false)
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                transform.position += Vector3.up * Time.deltaTime;
            }
            if (Input.GetKey(KeyCode.DownArrow))
            {
                transform.position += Vector3.down * Time.deltaTime;
            }
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                transform.position += Vector3.left * Time.deltaTime;
            }
            if (Input.GetKey(KeyCode.RightArrow))
            {
                transform.position += Vector3.right * Time.deltaTime;
            }
        }
    }

    public void Deathcheck()
    {
        if (GUIManager.Instance.curhp > 0)
        {
            playerdeath = false;
            gameObject.GetComponent<SpriteRenderer>().sprite = live;
        }
        else if (GUIManager.Instance.curhp <= 0)
        {
            playerdeath = true;
            gameObject.GetComponent<SpriteRenderer>().sprite = death;
        }
    }
}
